typedef union {
  Stmt	       *stmt;
  Expr	       *expr;
  int		integer;
  Objid		object;
  double       *real;
  char	       *string;
  enum error	error;
  Arg_List     *args;
  Cond_Arm     *arm;
  Except_Arm   *except;
  Scatter      *scatter;
} YYSTYPE;
#define	tINTEGER	258
#define	tOBJECT	259
#define	tFLOAT	260
#define	tSTRING	261
#define	tID	262
#define	tERROR	263
#define	tIF	264
#define	tELSE	265
#define	tELSEIF	266
#define	tENDIF	267
#define	tFOR	268
#define	tIN	269
#define	tENDFOR	270
#define	tRETURN	271
#define	tFORK	272
#define	tENDFORK	273
#define	tWHILE	274
#define	tENDWHILE	275
#define	tTRY	276
#define	tENDTRY	277
#define	tEXCEPT	278
#define	tFINALLY	279
#define	tANY	280
#define	tBREAK	281
#define	tCONTINUE	282
#define	tTO	283
#define	tARROW	284
#define	tOR	285
#define	tAND	286
#define	tEQ	287
#define	tNE	288
#define	tLE	289
#define	tGE	290
#define	tUNARYMINUS	291


extern YYSTYPE yylval;
